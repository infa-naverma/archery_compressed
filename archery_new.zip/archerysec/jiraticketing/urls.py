# -*- coding: utf-8 -*-
#                    _
#     /\            | |
#    /  \   _ __ ___| |__   ___ _ __ _   _
#   / /\ \ | '__/ __| '_ \ / _ \ '__| | | |
#  / ____ \| | | (__| | | |  __/ |  | |_| |
# /_/    \_\_|  \___|_| |_|\___|_|   \__, |
#                                     __/ |
#                                    |___/
# Copyright (C) 2017 Anand Tiwari
#
# Email:   anandtiwarics@gmail.com
# Twitter: @anandtiwarics
#
# This file is part of ArcherySec Project.

from django.urls import include, path

from jiraticketing import views

app_name = "jiraticketing"

urlpatterns = [
    path("jira_setting/", views.JiraSetting.as_view(), name="jira_setting"),
    path(
        "submit_jira_ticket/",
        views.CreateJiraTicket.as_view(),
        name="submit_jira_ticket",
    ),
]
