All code contributions are greatly appreciated. First off, clone the  [Git repository](https://github.com/archerysec/archerysec), read the user's manual carefully, go through the code yourself.

Bug reports are welcome! Please report all bugs on the [issue tracker](https://github.com/archerysec/archerysec/issues). Our preferred method of patch submission is via a Git pull request.

Many people have contributed in different ways to the Archery development. You can be the next!


##### Most active and Core Developer

* Anand Tiwari ([@anandtiwarics](https://twitter.com/anandtiwarics))

You can contact him, in case of any query related to tool.

##### Helping hands

* Shubham Mittal ([@upgoingstar](https://twitter.com/upgoingstar))
* Sudhanshu Chauhan ([@sudhanshu_c](https://twitter.com/sudhanshu_c))

