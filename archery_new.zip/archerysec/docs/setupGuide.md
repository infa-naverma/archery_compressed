##Setup Settings

###Zap Setting

1. Go to Setting Page
2. Edit ZAP setting or navigate URL : http://host:port/setting_edit/
3. Fill all required information and click on save.

<iframe width="854" height="480" src="https://www.youtube.com/embed/tkauGIaohK0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

###OpenVAS Setting

1. Go to setting Page
2. Edit OpenVAS setting or navigate URL : http://host:port/networkscanners/openvas_setting
3. Fill all required information and click on save.


